import "./App.css"
import Balance from "./components/Balance/Balance"
import Header from "./components/Header/Header"

function HomePage() {

  return (
    <>
    <Balance/>
    <Header/>
    </>
  )
}

export default HomePage
